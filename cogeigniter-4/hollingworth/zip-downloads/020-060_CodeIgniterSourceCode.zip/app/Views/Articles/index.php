<?= $this->include("header") ?>

    <h1>Articles</h1>

</body>
</html>
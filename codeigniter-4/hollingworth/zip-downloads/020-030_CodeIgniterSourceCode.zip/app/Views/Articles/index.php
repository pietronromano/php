<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Articles</title>
</head>
<body>

    <h1>Articles</h1>

</body>
</html>